import numpy as np
import math

def SVA(img_H):

    img_real = np.real(img_H)
    img_imag = np.imag(img_H)
    l = range(len(img_H))
    h = range(len(img_H[0]))
    img_HZ = np.zeros((193, 193, 2))
    img_realz = img_HZ[..., 0]
    img_imagz = img_HZ[..., 1]

    for j in l:

        for i in h:
            if i <= 1:
                img_realz[j, i] = img_real[j, i]
            elif i < 192:
                w1 = img_real[j, i] / (img_real[j, i + 1] + img_real[j, i - 1] + 0.000001)
                if w1 < 0:
                    ww = 0
                elif w1 <= 0.5:
                    ww = w1
                else:
                    ww = 0.5;
                img_realz[j, i] = img_real[j, i] - ww * (img_real[j, i + 1] + img_real[j, i - 1])
            else:
                img_realz[j, i] = img_real[j, i]

    for j in l:

        for i in h:
            # if i <= 1:
            # img_realz[j,i] = img_real[j,i]
            if i < 192:
                w2 = img_imag[j, i] / (img_imag[j, i + 1] + img_imag[j, i - 1] + 0.000001)
                if w2 < 0:
                    ww = 0
                elif w2 <= 0.5:
                    ww = w2
                else:
                    ww = 0.5;
                img_imagz[j, i] = img_imag[j, i] - ww * (img_imag[j, i + 1] + img_imag[j, i - 1])
            else:
                img_imagz[j, i] = img_imag[j, i]

    return img_realz + img_imagz